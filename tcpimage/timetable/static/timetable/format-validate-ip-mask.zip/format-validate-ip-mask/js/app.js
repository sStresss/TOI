$(document).ready(function(){
    $('[ip-mask]').ipAddress();
});